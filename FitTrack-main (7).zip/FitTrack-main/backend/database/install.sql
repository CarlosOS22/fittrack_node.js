-- ============================================
-- INSTALACIÓN COMPLETA DE FITTRACK
-- ============================================

-- Crear base de datos
CREATE DATABASE IF NOT EXISTS fittrack CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE fittrack;

-- ============================================
-- TABLA: users
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLA: user_data
-- ============================================
CREATE TABLE IF NOT EXISTS user_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    currentWeight DECIMAL(5,2),
    height DECIMAL(5,2),
    age INT,
    gender VARCHAR(10),
    activity_level VARCHAR(20),
    targetWeight DECIMAL(5,2),
    timeframeWeeks INT DEFAULT 12,
    goal VARCHAR(20) DEFAULT 'maintain',
    tdee INT,
    dailyCalories INT,
    macros JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLA: weekly_plan
-- ============================================
CREATE TABLE IF NOT EXISTS weekly_plan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    day VARCHAR(20) NOT NULL,
    type ENUM('recipe', 'exercise') NOT NULL,
    item_id INT NOT NULL,
    item_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLA: progress
-- ============================================
CREATE TABLE IF NOT EXISTS progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    date DATE NOT NULL,
    weight DECIMAL(5,2),
    measurements JSON,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLA: shopping_list
-- ============================================
CREATE TABLE IF NOT EXISTS shopping_list (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    ingredient VARCHAR(255) NOT NULL,
    quantity VARCHAR(50),
    checked BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- DATOS DE EJEMPLO
-- ============================================

-- Usuario de demostración
-- Email: demo@fittrack.com
-- Contraseña: demo123
INSERT INTO users (name, email, password) VALUES
('Usuario Demo', 'demo@fittrack.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Datos de perfil del usuario demo
SET @demo_user_id = LAST_INSERT_ID();

INSERT INTO user_data (user_id, currentWeight, height, age, gender, activity_level, targetWeight, timeframeWeeks, goal, tdee, dailyCalories, macros) VALUES
(@demo_user_id, 75.0, 175, 28, 'male', 'moderate', 70.0, 12, 'lose', 2400, 1900, '{"protein": 150, "carbs": 190, "fat": 53}');

-- ============================================
-- CONFIRMACIÓN
-- ============================================

SELECT '✅ Base de datos creada correctamente' AS Mensaje;
SELECT CONCAT('✅ Usuario demo creado: demo@fittrack.com / demo123') AS Usuario;
SELECT '✅ Tablas creadas correctamente' AS Tablas;
SELECT '🎉 ¡Instalación completada!' AS Estado;

-- Mostrar resumen
SELECT
    (SELECT COUNT(*) FROM users) as 'Usuarios',
    (SELECT COUNT(*) FROM user_data) as 'Perfiles',
    (SELECT COUNT(*) FROM weekly_plan) as 'Planes',
    (SELECT COUNT(*) FROM progress) as 'Registros de Progreso',
    (SELECT COUNT(*) FROM shopping_list) as 'Items en Lista'
as 'Resumen de Datos';
