# 📦 Guía de Despliegue de FitTrack

Esta guía te ayudará a desplegar tu aplicación FitTrack sin necesidad de usar Vite en modo desarrollo.

## ✅ Build de Producción Completado

Tu aplicación ya está compilada y lista para desplegar. Los archivos se encuentran en:
```
/home/user/FitTrack/frontend/dist/
```

---

## 🚀 Opciones de Despliegue

### ⚠️ IMPORTANTE sobre Google Drive

**Google Drive NO es recomendado** para hospedar aplicaciones web porque:
- No permite ejecutar código JavaScript correctamente
- No soporta configuración de CORS
- No puede servir archivos con los headers correctos
- No funciona como servidor web

### ✅ Opciones Recomendadas (GRATIS):

#### **1. GitHub Pages** (⭐ Recomendado - Gratis)
Hosting gratuito de GitHub, ideal para proyectos estáticos.

**Pasos:**
1. Asegúrate de que tu código esté en GitHub
2. Ve a tu repositorio en GitHub
3. Ve a **Settings** → **Pages**
4. En "Source", selecciona la rama que contiene `dist/`
5. En "Folder", selecciona `/dist`
6. Haz clic en **Save**
7. Tu app estará disponible en: `https://tu-usuario.github.io/FitTrack/`

**Nota**: Tu backend seguirá corriendo localmente en XAMPP.

#### **2. Netlify** (⭐ Recomendado - Gratis)
Hosting especializado en aplicaciones React.

**Pasos:**
1. Ve a [netlify.com](https://netlify.com)
2. Regístrate gratis
3. Arrastra la carpeta `dist/` a Netlify (Drag & Drop)
4. Tu app estará online en minutos
5. URL: `https://tu-app.netlify.app`

#### **3. Vercel** (Gratis)
Otra opción excelente para React.

**Pasos:**
1. Ve a [vercel.com](https://vercel.com)
2. Regístrate gratis
3. Conecta tu repositorio de GitHub
4. Vercel detectará automáticamente Vite
5. Deploy automático

#### **4. Hosting Local (Para uso personal)**
Si solo quieres usarlo tú desde tu PC:

**Pasos:**
1. Copia la carpeta `dist/` a tu carpeta de XAMPP:
   ```
   C:\xampp\htdocs\fittrack-app\
   ```
   o
   ```
   C:\xampp2\htdocs\fittrack-app\
   ```

2. Abre en tu navegador:
   ```
   http://localhost/fittrack-app/
   ```

---

## 🔧 Configuración del Backend

### Opción A: Backend Local (XAMPP)

Tu backend seguirá corriendo en tu PC local:

1. **Asegúrate de que XAMPP esté corriendo**:
   - Apache
   - MySQL

2. **Tu backend está en**:
   ```
   http://localhost/fittrackapp/backend/api
   ```

3. **La aplicación frontend** (compilada) se conectará automáticamente a esta URL

### Opción B: Subir Backend a Hosting

Si quieres que otras personas usen tu app, necesitas subir el backend a un hosting PHP:

**Hosting PHP Gratuitos:**
- InfinityFree (gratis, sin anuncios)
- 000webhost (gratis)
- AwardSpace (gratis)

**Pasos para subir backend:**
1. Comprime la carpeta `backend/` en un ZIP
2. Sube el ZIP a tu hosting PHP
3. Extrae los archivos
4. Importa la base de datos MySQL
5. Actualiza `/frontend/.env.production`:
   ```
   VITE_API_URL=https://tu-hosting.com/backend/api
   ```
6. Vuelve a ejecutar: `npm run build`

---

## 📁 Estructura de Archivos del Build

```
dist/
├── index.html          (Tu página principal)
├── assets/
│   ├── index-xxx.js    (JavaScript compilado)
│   └── index-xxx.css   (Estilos compilados)
└── ...
```

**Estos son los archivos que debes subir** a tu hosting elegido.

---

## 🌐 URLs después del Despliegue

### Frontend (Opciones):
- **GitHub Pages**: `https://carlosos22.github.io/FitTrack/`
- **Netlify**: `https://fittrack.netlify.app`
- **Vercel**: `https://fittrack.vercel.app`
- **Local**: `http://localhost/fittrack-app/`

### Backend:
- **Local (desarrollo)**: `http://localhost/fittrackapp/backend/api`
- **Producción (si subes)**: `https://tu-dominio.com/backend/api`

---

## 🔄 Actualizar la Aplicación

Cuando hagas cambios en el código:

1. **Guarda los cambios** en el código
2. **Ejecuta el build**:
   ```bash
   cd /home/user/FitTrack/frontend
   npm run build
   ```
3. **Sube la nueva carpeta `dist/`** a tu hosting

---

## ⚙️ Cambios Realizados para Despliegue

### 1. **HashRouter en lugar de BrowserRouter**
- Ahora las URLs usan `#` (ej: `example.com/#/recipes`)
- Esto permite que funcione en hosting estático sin configuración del servidor

### 2. **Variables de Entorno**
- `.env.development` - URL del API para desarrollo
- `.env.production` - URL del API para producción

### 3. **Build Optimizado**
- Todo el código está minificado
- Tamaño reducido para carga rápida
- Compatible con todos los navegadores modernos

---

## 🆘 Solución de Problemas

### Problema: "Failed to fetch" o errores de CORS

**Solución:**
1. Verifica que tu backend (XAMPP) esté corriendo
2. Asegúrate de que `.env.production` tenga la URL correcta:
   ```
   VITE_API_URL=http://localhost/fittrackapp/backend/api
   ```
3. Verifica que `cors-handler.php` esté funcionando

### Problema: Las rutas no funcionan (404)

**Solución:**
- Usa siempre el menú de navegación interno
- Las URLs con `#` deberían funcionar: `example.com/#/recipes`

### Problema: La aplicación no carga en el navegador

**Solución:**
1. Abre las DevTools (F12)
2. Ve a la pestaña Console
3. Busca errores en rojo
4. Si ves errores de "module not found", asegúrate de subir TODA la carpeta `dist/`

---

## 📝 Resumen Rápido

### Para usar localmente:
```bash
# 1. Copia dist/ a XAMPP
cp -r frontend/dist/* C:/xampp/htdocs/fittrack-app/

# 2. Abre en navegador
http://localhost/fittrack-app/
```

### Para subir a GitHub Pages:
```bash
# 1. Commit y push
git add .
git commit -m "Build production"
git push

# 2. Configura GitHub Pages desde Settings
# Selecciona: Branch > main > /dist
```

### Para Netlify/Vercel:
```bash
# Arrastra la carpeta dist/ a su página web
# ¡Listo!
```

---

## ✅ Verificación Final

Antes de compartir tu app, verifica:

- [ ] El build se completó sin errores
- [ ] Todas las páginas cargan correctamente
- [ ] Puedes iniciar sesión
- [ ] Las recetas se muestran
- [ ] El plan semanal funciona
- [ ] La lista de compra funciona
- [ ] El backend responde (XAMPP corriendo)

---

## 🎉 ¡Listo!

Tu aplicación FitTrack está lista para ser desplegada. Elige la opción de hosting que prefieras y sigue los pasos correspondientes.

**Recomendación**: Usa **Netlify** o **GitHub Pages** para el frontend, y mantén el backend en XAMPP local si es solo para uso personal.

Si quieres que otras personas lo usen, necesitarás subir el backend a un hosting PHP con MySQL.
