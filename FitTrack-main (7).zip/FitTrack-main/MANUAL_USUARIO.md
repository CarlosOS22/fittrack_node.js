# 📖 MANUAL DE USUARIO - FitTrack

**Aplicación de Gestión Nutricional y Fitness**

---

## 🎯 Introducción

Bienvenido a FitTrack, tu compañero digital para alcanzar tus objetivos de salud y fitness. Este manual te guiará paso a paso para aprovechar al máximo todas las funcionalidades de la aplicación.

---

## 📑 Contenido

1. [Instalación](#instalación)
2. [Primer Uso](#primer-uso)
3. [Funcionalidades Principales](#funcionalidades)
4. [Preguntas Frecuentes](#faq)
5. [Solución de Problemas](#problemas)

---

## 1. INSTALACIÓN {#instalación}

### Requisitos del Sistema

- **Sistema Operativo:** Windows 7 o superior
- **Software Necesario:** XAMPP (Apache + MySQL + PHP)
- **Espacio en Disco:** 500 MB mínimo
- **Navegador:** Chrome, Firefox, Edge o Safari (última versión)

### Proceso de Instalación

#### Paso 1: Instalar XAMPP

1. Descarga XAMPP desde: https://www.apachefriends.org/download.html
2. Ejecuta el instalador
3. Acepta la configuración por defecto
4. Espera a que finalice la instalación (5-10 minutos)

#### Paso 2: Instalar FitTrack

1. Descarga el archivo FitTrack.zip
2. Descomprime el archivo en cualquier carpeta
3. Busca y ejecuta el archivo `INSTALAR.bat`
4. Sigue las instrucciones en pantalla

#### Paso 3: Configurar Base de Datos

1. Abre el Panel de Control de XAMPP
2. Inicia los servicios Apache y MySQL (botón "Start")
3. Abre tu navegador y ve a: http://localhost/phpmyadmin
4. Sigue las instrucciones del instalador para crear la base de datos

#### Paso 4: Primer Acceso

1. Abre tu navegador
2. Ve a: http://localhost/fittrackapp
3. ¡La aplicación está lista para usar!

---

## 2. PRIMER USO {#primer-uso}

### Crear tu Cuenta

1. En la página principal, haz clic en **"Registrarse"**
2. Completa el formulario:
   - **Nombre completo**
   - **Email** (será tu nombre de usuario)
   - **Contraseña** (mínimo 6 caracteres)
   - **Confirmar contraseña**
3. Haz clic en **"Crear Cuenta"**
4. Serás redirigido al dashboard

### Configurar tu Perfil

Es importante completar tu perfil para que FitTrack pueda calcular tus necesidades nutricionales:

1. Haz clic en tu nombre (esquina superior derecha)
2. Selecciona **"Mi Perfil"**
3. Ve a la pestaña **"Datos Fitness"**
4. Completa todos los campos:

   **Datos Personales:**
   - Edad (años)
   - Género (Masculino/Femenino)
   - Altura (en centímetros)
   - Peso Actual (en kilogramos)

   **Objetivos:**
   - Peso Objetivo (kg)
   - Objetivo (Perder peso / Mantener peso / Ganar músculo)
   - Timeframe (semanas para alcanzar tu objetivo)
   - Nivel de Actividad:
     * **Sedentario:** Poco o ningún ejercicio
     * **Ligero:** Ejercicio ligero 1-3 días/semana
     * **Moderado:** Ejercicio moderado 3-5 días/semana
     * **Activo:** Ejercicio intenso 6-7 días/semana
     * **Muy Activo:** Ejercicio muy intenso + trabajo físico

5. Haz clic en **"Guardar Datos de Fitness"**

### Resultado del Cálculo

Una vez guardados tus datos, FitTrack calculará automáticamente:

- **TDEE** (Gasto Energético Total Diario)
- **Calorías Diarias** recomendadas según tu objetivo
- **Distribución de Macronutrientes:**
  - Proteínas (gramos)
  - Carbohidratos (gramos)
  - Grasas (gramos)

Estos valores aparecerán en tu perfil y en el Dashboard.

---

## 3. FUNCIONALIDADES PRINCIPALES {#funcionalidades}

### 3.1 Dashboard / Inicio

Tu centro de control personal.

**Qué encontrarás:**
- Resumen de tu perfil nutricional
- Calorías y macros recomendados
- Botón para generar plan automático
- Acceso rápido a todas las secciones

**Cómo usar:**
1. Revisa tus estadísticas diarias
2. Usa el botón "Generar Plan Automático" para crear un plan semanal completo
3. Navega a las diferentes secciones según tus necesidades

### 3.2 Recetas

Base de datos con más de 380 recetas saludables.

**Categorías disponibles:**
- 🌅 Desayunos (80+ recetas)
- 🍽️ Almuerzos (100+ recetas)
- 🌙 Cenas (100+ recetas)
- 🍎 Meriendas (50+ recetas)
- 🥤 Batidos (30+ recetas)
- 🍰 Postres Saludables (20+ recetas)

**Cómo usar:**
1. Haz clic en "Recetas" en el menú
2. Navega por las categorías o usa el filtro
3. Haz clic en una receta para ver detalles:
   - Información nutricional completa
   - Lista de ingredientes
   - Instrucciones de preparación
   - Tiempo de cocción
4. Para añadirla a tu plan:
   - Haz clic en "Añadir al Plan"
   - Selecciona el día de la semana
   - Confirma

**Información de cada receta:**
- 🔥 Calorías
- 🥩 Proteínas
- 🍞 Carbohidratos
- 🥑 Grasas
- ⏱️ Tiempo de preparación
- 📊 Dificultad

### 3.3 Ejercicios

Biblioteca con 100+ ejercicios con GIFs animados.

**Grupos musculares:**
- 💪 Pecho
- 🏋️ Espalda
- 🦾 Hombros
- 💪 Bíceps
- 💪 Tríceps
- 🦵 Piernas
- 🍑 Glúteos
- 🏃 Abdominales
- 🏃 Cardio

**Cómo usar:**
1. Haz clic en "Ejercicios" en el menú
2. Selecciona el grupo muscular
3. Haz clic en un ejercicio para ver:
   - GIF animado con la técnica correcta
   - Descripción del ejercicio
   - Músculos trabajados
   - Series y repeticiones recomendadas
   - Consejos de ejecución
4. Añade al plan semanal haciendo clic en "Añadir a Rutina"

### 3.4 Plan Semanal

Tu planificador personal de comidas y ejercicios.

**Características:**
- Vista organizada por días (Lunes a Domingo)
- Resumen nutricional por día
- Comparación con tus objetivos
- Tabla resumen semanal

**Cómo usar:**

**Añadir recetas manualmente:**
1. Ve a "Plan Semanal"
2. Haz clic en el día deseado
3. Haz clic en "Añadir Receta"
4. Selecciona la receta
5. Confirma

**Añadir ejercicios:**
1. Haz clic en "Añadir Ejercicio"
2. Selecciona el ejercicio
3. Configura series y repeticiones
4. Confirma

**Ver resumen nutricional:**
- Cada día muestra:
  - Calorías totales del día
  - Proteínas, carbos y grasas
  - Barras de progreso vs. objetivo
  - Porcentaje alcanzado

**Eliminar items:**
- Haz clic en el icono de basura (🗑️) junto al item
- Confirma la eliminación

### 3.5 Lista de Compra

Generador inteligente de listas de compra.

**Funcionalidades:**
- Generación automática desde el plan semanal
- Unificación de ingredientes similares
- Suma automática de cantidades
- Marcado de items comprados
- Eliminación de items comprados

**Cómo usar:**

**Generar lista automáticamente:**
1. Ve a "Lista de Compra"
2. Haz clic en "Generar desde Plan Semanal"
3. El sistema:
   - Extrae todos los ingredientes de tus recetas
   - Identifica ingredientes similares (ej: "huevos", "huevo")
   - Suma las cantidades automáticamente
   - Presenta la lista unificada

**Ejemplo de unificación:**
- Tu plan tiene:
  - "2 huevos" (Lunes)
  - "4 claras de huevo" (Miércoles)
  - "1 huevo entero" (Viernes)
- Resultado en la lista: **"7 Huevos"**

**Marcar como comprado:**
- Haz clic en el checkbox junto al item
- El item se moverá a la sección "Comprados"

**Eliminar comprados:**
- Haz clic en "Limpiar Comprados"
- Todos los items marcados se eliminarán

**Añadir items manualmente:**
1. Escribe el nombre del ingrediente
2. (Opcional) Añade la cantidad
3. Haz clic en "Añadir"

### 3.6 Progreso

Sistema de seguimiento de tu evolución.

**Qué puedes registrar:**
- Peso corporal
- Porcentaje de grasa
- Medidas corporales
- Notas personales
- Fotos de progreso (próximamente)

**Cómo usar:**

**Registrar nuevo dato:**
1. Ve a "Progreso"
2. Haz clic en "Nuevo Registro"
3. Completa:
   - Fecha (automática, editable)
   - Peso actual
   - % de grasa corporal (opcional)
   - Notas (opcional)
4. Haz clic en "Guardar"

**Ver gráficas:**
- La gráfica muestra tu evolución de peso en el tiempo
- Líneas de tendencia automáticas
- Zoom y navegación interactiva

**Analizar estadísticas:**
El panel de estadísticas muestra:
- Peso inicial
- Peso actual
- Peso objetivo
- Cambio total (kg)
- Cambio porcentual
- Progreso hacia el objetivo

**Eliminar registros:**
- Haz clic en el icono de basura junto al registro
- Confirma la eliminación

### 3.7 Mi Perfil

Gestión de tu cuenta y configuración.

**Pestañas disponibles:**

**1. Perfil**
- Editar nombre
- Cambiar email
- Ver fecha de registro

**2. Datos Fitness**
- Actualizar peso actual
- Modificar objetivo
- Cambiar nivel de actividad
- Ajustar timeframe

**3. Preferencias**
- Notificaciones
- Idioma (próximamente)
- Unidades de medida (próximamente)

**4. Seguridad**
- Cambiar contraseña
- Eliminar cuenta

**Importante:** Cada vez que modificas tus datos fitness, FitTrack recalcula automáticamente tus calorías y macros.

---

## 4. PREGUNTAS FRECUENTES {#faq}

### General

**P: ¿Necesito Internet para usar FitTrack?**
R: No, FitTrack funciona completamente offline una vez instalado. Solo necesitas XAMPP corriendo en tu PC.

**P: ¿Mis datos están seguros?**
R: Sí, todos los datos se almacenan localmente en tu PC. Las contraseñas están encriptadas con bcrypt.

**P: ¿Puedo usar FitTrack en mi teléfono?**
R: La interfaz es responsive y funciona en navegadores móviles, pero necesitas acceder desde la misma red local donde está instalado.

**P: ¿Cuántas recetas tiene FitTrack?**
R: Actualmente hay más de 380 recetas saludables en diversas categorías.

### Cálculos Nutricionales

**P: ¿Cómo calcula FitTrack mis calorías?**
R: Usa la ecuación de Mifflin-St Jeor, validada científicamente, considerando tu peso, altura, edad, género y nivel de actividad.

**P: ¿Puedo cambiar mis macros manualmente?**
R: Por ahora los macros se calculan automáticamente según tu objetivo. Futuras versiones permitirán personalización.

**P: ¿Por qué mis calorías cambiaron?**
R: Las calorías se recalculan cada vez que actualizas tus datos de perfil (peso, actividad, objetivo).

### Plan Semanal

**P: ¿Puedo repetir recetas en diferentes días?**
R: Sí, puedes añadir la misma receta múltiples veces.

**P: ¿Se guarda mi plan si cierro sesión?**
R: Sí, todo se guarda en la base de datos y estará disponible cuando vuelvas a iniciar sesión.

**P: ¿Puedo imprimir mi plan semanal?**
R: Usa Ctrl+P en la página del plan semanal. Futuras versiones tendrán exportación a PDF.

### Lista de Compra

**P: ¿Por qué algunos ingredientes no se unificaron?**
R: El sistema unifica ingredientes similares, pero si están escritos muy diferente, pueden aparecer separados.

**P: ¿Puedo editar las cantidades en la lista?**
R: Actualmente no, pero puedes eliminar el item y añadirlo manualmente con la cantidad deseada.

**P: ¿Se eliminan los duplicados si regenero la lista?**
R: Sí, el sistema verifica qué ingredientes ya existen y solo añade los nuevos.

---

## 5. SOLUCIÓN DE PROBLEMAS {#problemas}

### Problema: No puedo acceder a FitTrack

**Síntomas:**
- El navegador muestra "No se puede acceder al sitio"
- Error "ERR_CONNECTION_REFUSED"

**Soluciones:**
1. Verifica que XAMPP esté corriendo:
   - Abre "XAMPP Control Panel"
   - Apache debe estar en verde (Start)
   - MySQL debe estar en verde (Start)
2. Verifica la URL: debe ser `http://localhost/fittrackapp`
3. Si Apache no inicia, revisa que el puerto 80 esté libre
4. Reinicia XAMPP y prueba de nuevo

### Problema: "Failed to fetch" o errores de API

**Síntomas:**
- Mensajes de error al iniciar sesión
- Datos no se guardan
- Página en blanco

**Soluciones:**
1. Verifica que MySQL esté corriendo en XAMPP
2. Ve a `http://localhost/phpmyadmin` para verificar la base de datos
3. Asegúrate de que la base "fittrack" existe
4. Limpia la caché del navegador (Ctrl+Shift+Supr)
5. Recarga la página (F5)

### Problema: Calorías aparecen como "NaN"

**Síntomas:**
- En tu perfil, las calorías muestran "NaN"
- Los macros muestran "NaN"

**Soluciones:**
1. Verifica que completaste TODOS los campos del perfil
2. Cierra sesión y vuelve a iniciar
3. Ve a phpMyAdmin y verifica que la tabla `user_data` tenga las columnas correctas
4. Si el problema persiste, ejecuta de nuevo el instalador

### Problema: Plan semanal en blanco

**Síntomas:**
- No se ven las recetas/ejercicios añadidos
- La página está vacía

**Soluciones:**
1. Recarga la página (F5)
2. Verifica que iniciaste sesión
3. Añade una receta de nuevo
4. Revisa la consola del navegador (F12) para errores

### Problema: Lista de compra no se genera

**Síntomas:**
- Al hacer clic en "Generar" no pasa nada
- Sale un error

**Soluciones:**
1. Verifica que tengas recetas en tu plan semanal
2. Recarga la página
3. Limpia la lista actual e intenta de nuevo
4. Verifica que XAMPP esté corriendo

### Problema: No puedo iniciar sesión

**Síntomas:**
- Email y contraseña no funcionan
- Error de credenciales

**Soluciones:**
1. Verifica que escribiste correctamente el email
2. La contraseña distingue mayúsculas y minúsculas
3. Si olvidaste tu contraseña, puedes:
   - Crear una nueva cuenta
   - O usar phpMyAdmin para resetearla (avanzado)

### Problema: XAMPP no inicia Apache

**Síntomas:**
- Apache no pasa a verde
- Error de puerto ocupado

**Soluciones:**
1. Otro programa está usando el puerto 80:
   - Cierra Skype
   - Cierra Discord
   - Verifica programas de virtualización
2. Cambia el puerto de Apache:
   - En XAMPP, haz clic en "Config" (Apache)
   - Edita httpd.conf
   - Cambia `Listen 80` a `Listen 8080`
   - Guarda y reinicia Apache
   - Usa `http://localhost:8080/fittrackapp`

---

## 📞 Soporte Adicional

Si sigues teniendo problemas:

1. Abre las DevTools del navegador (F12)
2. Ve a la pestaña "Console"
3. Busca mensajes de error en rojo
4. Copia el error completo
5. Consulta con tu profesor o compañeros

---

## 🎓 Consejos de Uso

### Para Mejores Resultados:

1. **Sé consistente:** Actualiza tu progreso semanalmente
2. **Sé honesto:** Ingresa tus datos reales
3. **Sé paciente:** Los cambios toman tiempo
4. **Planifica:** Dedica 10-15 minutos cada domingo a planificar tu semana
5. **Ajusta:** Si no ves resultados en 4 semanas, ajusta tus datos

### Workflow Recomendado:

**Domingo:**
1. Registra tu peso semanal
2. Revisa tu progreso
3. Planifica la semana siguiente
4. Genera tu lista de compra
5. Ve al super

**Durante la semana:**
6. Sigue tu plan
7. Marca los items comprados
8. Ajusta según necesites

**Siguiente domingo:**
- Repite el ciclo

---

## ✅ Checklist de Primer Uso

Marca cada paso al completarlo:

- [ ] XAMPP instalado y configurado
- [ ] FitTrack instalado correctamente
- [ ] Base de datos creada
- [ ] Cuenta de usuario creada
- [ ] Perfil completado con todos los datos
- [ ] Calorías calculadas correctamente
- [ ] Exploré el catálogo de recetas
- [ ] Exploré los ejercicios
- [ ] Creé mi primer plan semanal
- [ ] Generé mi primera lista de compra
- [ ] Registré mi primer dato de progreso
- [ ] Guardé el acceso directo en mi escritorio

---

## 📚 Recursos Adicionales

**En la aplicación encontrarás:**
- Información nutricional detallada en cada receta
- GIFs instructivos en cada ejercicio
- Gráficas interactivas de progreso
- Tips nutricionales (próximamente)

**Archivos incluidos:**
- `LEEME.txt` - Guía de instalación rápida
- `PROYECTO_ACADEMICO.md` - Documentación técnica
- `COMO_COMPARTIR.txt` - Guía para compartir la app

---

**¡Disfruta FitTrack y alcanza tus objetivos! 💪**

---

*Última actualización: Noviembre 2025*
*Versión: 1.0*
